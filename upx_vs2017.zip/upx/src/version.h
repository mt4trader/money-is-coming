#define UPX_VERSION_HEX         0x035e00        /* 03.94.00 */
#define UPX_VERSION_STRING      "3.94"
#define UPX_VERSION_STRING4     "3.94"
#define UPX_VERSION_DATE        "May 12th 2017"
#define UPX_VERSION_DATE_ISO    "2017-05-12"
#define UPX_VERSION_YEAR        "2017"

/* vim:set ts=4 sw=4 et: */
